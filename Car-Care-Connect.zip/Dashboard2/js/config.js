export const SUPABASE_CONFIG = {
    SUPABASE_URL: 'https://fossoibkacvvhitsnfhv.supabase.co',
    SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZvc3NvaWJrYWN2dmhpdHNuZmh2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzM1OTMxODEsImV4cCI6MjA0OTE2OTE4MX0.UgiksbLKT8bNsD_fvMldt08ObaW0-chSHWBJbqNqS4E'
};